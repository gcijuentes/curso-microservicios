package com.persona.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.persona.entity.Persona;
import com.persona.model.PersonaRest;
import com.persona.repository.PersonaRepository;
import com.persona.service.PersonaService;

@Service
public class PersonaServiceImpl implements PersonaService{

	@Autowired
	private PersonaRepository personaRepository;
	
	@Value("${config.balanceador.test}")
	private String balanceador;
	
	@Override
	public List<PersonaRest> getPersonas() {
		
		List<Persona> listPersona = personaRepository.findAll();
		
		List<PersonaRest> listPersonaRest = new ArrayList<>();

		listPersona.stream().forEach((Persona persona)->{
			
			PersonaRest personaRest  = new PersonaRest();
			personaRest.setApellido(persona.getApellido());
			personaRest.setDireccion(persona.getDireccion());
			personaRest.setFechaNacimiento(persona.getFechaNacimiento());
			personaRest.setId(persona.getId());
			personaRest.setNombre(persona.getNombre());
			personaRest.setUsername(persona.getUsername());
			personaRest.setBalanceador(balanceador);
			
			listPersonaRest.add(personaRest);
			
		});
		
		
		return listPersonaRest;
	}
	
	
}
