package com.datos.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.datos.model.DatosPersonaRest;

@FeignClient(name="microservicio-persona")
public interface PersonaFeignClient {

	@GetMapping("/personas")
	List<DatosPersonaRest> getPersonas();
	
}
