package com.datos.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.datos.feign.PersonaFeignClient;
import com.datos.model.DatosPersonaRest;
import com.datos.service.DatosService;

@Service
public class DatosServiceImpl implements DatosService{

	@Autowired
	private PersonaFeignClient personaFeignClient;
	
	@Override
	public List<DatosPersonaRest> getDatosPersonas() {

		List<DatosPersonaRest> listDatosPersonaRest = personaFeignClient.getPersonas();
		
		return listDatosPersonaRest;
	}

	
}
